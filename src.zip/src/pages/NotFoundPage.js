import React from 'react'

const NotFoundPage = () => {
  return (
    <div className="ml-64"   style={{float:'center'}}>NotFoundPage</div>
  )
}

export default NotFoundPage