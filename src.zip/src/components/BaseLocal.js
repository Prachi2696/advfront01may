
// const BaseLocal ="http://10.210.8.60:8080/";
const BaseLocal ="http://localhost:8080/";

// const BaseLocal ="https://advservice.epramaan.gov.in/dynamic/";


export default BaseLocal
