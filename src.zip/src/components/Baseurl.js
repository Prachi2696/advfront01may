import React from 'react'

// const Baseurl ="http://10.210.8.60:8080/dept/";
const Baseurl ="http://localhost:8080/dept/";


// const Baseurl ="https://advservice.epramaan.gov.in/dynamic/dept/";


export default Baseurl
